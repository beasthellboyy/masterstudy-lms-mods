<?php stm_lms_register_style('courses/all_courses_link'); ?>

<a href="<?php echo STM_LMS_Course::courses_page_url() ?>" class="button wc-backward">
    <?php esc_html_e('View all courses', 'masterstudy-lms-learning-management-system'); ?>
</a>