<?php
if ( STM_LMS_Options::get_option( 'ms_plugin_preloader' ) ) {
	?>
	<div class="ms_plugin_loader_bg_">
		<div class="ms_lms_loader_"></div>
	</div>
	<?php
}
