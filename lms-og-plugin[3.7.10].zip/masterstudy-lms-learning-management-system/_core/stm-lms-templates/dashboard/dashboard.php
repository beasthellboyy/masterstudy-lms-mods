<div id="stm-lms-dashboard">

    <!--<div class="stm-lms-dashboard">-->

        <!--<navigation></navigation>-->

        <router-view></router-view>

    <!--</div>-->

</div>