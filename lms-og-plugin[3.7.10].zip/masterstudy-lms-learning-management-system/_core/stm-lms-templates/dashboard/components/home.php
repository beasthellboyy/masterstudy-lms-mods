<transition name="slide">

	<div class="dashboard-home">

		<div class="nav-links">

			<router-link to="/courses" class="nav-link nav-link-courses">

				<i class="stmlms-layers"></i>

				<h3><?php esc_html_e( 'Courses', 'masterstudy-lms-learning-management-system' ); ?></h3>

			</router-link>

		</div>

	</div>

</transition>
