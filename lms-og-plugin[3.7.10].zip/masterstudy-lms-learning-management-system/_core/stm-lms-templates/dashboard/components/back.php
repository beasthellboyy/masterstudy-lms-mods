<transition name="slide">
	<div>
		<a href="#" class="back" @click.prevent="goBack()">
			<?php esc_html_e( 'Back', 'masterstudy-lms-learning-management-system' ); ?>
		</a>
	</div>
</transition>
