<?php
/**
 * @var string $title
 */

?>

<h1 class="masterstudy-single-course-title"><?php echo esc_html( $title ); ?></h1>
