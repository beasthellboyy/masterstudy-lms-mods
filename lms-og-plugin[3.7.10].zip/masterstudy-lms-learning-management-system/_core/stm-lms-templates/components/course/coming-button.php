<div class="masterstudy-single-course-coming-button">
	<?php echo esc_html__( 'Coming soon', 'masterstudy-lms-learning-management-system' ); ?>
</div>
