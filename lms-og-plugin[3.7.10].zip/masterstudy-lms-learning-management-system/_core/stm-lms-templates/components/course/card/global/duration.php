<?php
/**
 * @var $course
 */
?>

<div class="masterstudy-course-card__meta-block">
	<i class="stmlms-lms-clocks"></i>
	<span>
		<?php echo esc_html( $course['duration_info'] ); ?>
	</span>
</div>
