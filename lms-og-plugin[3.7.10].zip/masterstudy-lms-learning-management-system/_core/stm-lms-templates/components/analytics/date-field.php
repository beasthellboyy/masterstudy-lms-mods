<?php wp_enqueue_style( 'masterstudy-date-field' ); ?>

<div class="masterstudy-date-field">
	<div class="masterstudy-date-field-label"></div>
	<div class="masterstudy-date-field-value"></div>
</div>
