<?php wp_enqueue_style( 'masterstudy-stats-loader' ); ?>

<div class="masterstudy-stats-loader">
	<img src="<?php echo esc_attr( STM_LMS_URL . 'assets/img/stats-loader.svg' ); ?>" class="masterstudy-stats-loader__image">
</div>
