<?php
wp_enqueue_style( 'masterstudy-separator' );
?>

<span class="masterstudy-separator">
	<span class="masterstudy-separator__filled"></span>
	<span class="masterstudy-separator__line"></span>
</span>
