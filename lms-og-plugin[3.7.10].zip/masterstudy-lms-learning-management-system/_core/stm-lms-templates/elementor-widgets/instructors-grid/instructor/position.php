<h4 class="ms_lms_instructors_grid__item_position">
	<?php echo esc_html( $user['meta']['position'] ); ?>
</h4>
