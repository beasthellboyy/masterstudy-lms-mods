<div class="masterstudy-elementor-course-note">
	<?php echo esc_html__( 'Note: This is a Course Page template. The course will be selected dynamically on the frontend. The selected course here is for preview only.', 'masterstudy-lms-learning-management-system' ); ?>
</div>
