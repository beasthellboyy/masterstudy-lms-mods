<div class="ms_lms_instructors_carousel__navigation">
	<button class="ms_lms_instructors_carousel__navigation_prev <?php echo ( ! empty( $navigation_arrows_presets ) ) ? esc_attr( $navigation_arrows_presets ) : 'style_1'; ?>">
		<i class="stmlms-chevron-left"></i>
	</button>
	<button class="ms_lms_instructors_carousel__navigation_next <?php echo ( ! empty( $navigation_arrows_presets ) ) ? esc_attr( $navigation_arrows_presets ) : 'style_1'; ?>">
		<i class="stmlms-chevron-right"></i>
	</button>
</div>
