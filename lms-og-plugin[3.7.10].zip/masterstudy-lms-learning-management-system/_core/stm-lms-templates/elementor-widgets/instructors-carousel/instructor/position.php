<h4 class="ms_lms_instructors_carousel__item_position">
	<?php echo esc_html( $user['meta']['position'] ); ?>
</h4>
