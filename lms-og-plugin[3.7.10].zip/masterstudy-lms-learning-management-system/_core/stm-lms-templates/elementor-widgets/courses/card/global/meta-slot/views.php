<i class="stmlms-views"></i>
<span><?php echo esc_html( $course['views'] ); ?></span>
