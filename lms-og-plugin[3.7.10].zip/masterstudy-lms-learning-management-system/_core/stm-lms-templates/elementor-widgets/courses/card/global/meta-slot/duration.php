<i class="stmlms-lms-clocks"></i>
<span><?php echo esc_html( ( ! empty( $course['duration_info'] ) ) ? $course['duration_info'] : '0 ' . __( 'Hours', 'masterstudy-lms-learning-management-system' ) ); ?></span>
