<i class="stmlms-members"></i>
<span><?php echo esc_html( $course['current_students'] ); ?></span>
