<div class="ms_lms_courses_archive__no-result">
	<div class="ms_lms_courses_archive__no-result_background">
		<i class="stmlms-not_found_courses"></i>
	</div>
	<p>
		<?php esc_html_e( 'No courses found', 'masterstudy-lms-learning-management-system' ); ?>
	</p>
	<a href="#" class="ms_lms_courses_archive__no-result_reset">
		<i class="stmlms-undo2"></i>
		<span><?php esc_html_e( 'Reset All', 'masterstudy-lms-learning-management-system' ); ?></span>
	</a>
</div>
