<?php
/**
 * @var $title
 */

?>

<div class="dropdown_menu_item__divider">
	<?php echo esc_html( $title ); ?>
</div>
