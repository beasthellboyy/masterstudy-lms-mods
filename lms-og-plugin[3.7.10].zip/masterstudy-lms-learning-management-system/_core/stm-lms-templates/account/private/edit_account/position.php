<div class="row">
	<div class="col-md-12">
		<div class="form-group form-group-social">
			<label class="heading_font"><?php esc_html_e( 'Position', 'masterstudy-lms-learning-management-system' ); ?></label>
			<input class="form-control masterstudy-edit-account-position-input" placeholder="<?php esc_html_e( 'Enter your position', 'masterstudy-lms-learning-management-system' ); ?>"/>
		</div>
	</div>
</div>
