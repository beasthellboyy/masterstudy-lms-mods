<a href="<?php echo esc_attr( wp_logout_url( get_home_url() ) ); ?>" class="stm-lms-logout-button btn btn-default">
	<i class="stmlms-power-off"></i>
	<span>
		<?php esc_html_e( 'Log out', 'masterstudy-lms-learning-management-system' ); ?>
	</span>
</a>
