<div class="stm_lms_splash_wizard__header">
	<div class="stm_lms_splash_wizard__header_logo">
		<img src="<?php echo esc_url( STM_LMS_URL . 'assets/img/wizard/logo.svg' ); ?>"/>
	</div>
	<?php STM_LMS_Templates::show_lms_template( 'wizard/views/nav' ); ?>
</div>
