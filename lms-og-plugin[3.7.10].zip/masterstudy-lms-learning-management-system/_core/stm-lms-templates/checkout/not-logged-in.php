<h3>
	<?php printf(__('Please, <a href="%s">log in</a>', 'masterstudy-lms-learning-management-system'), STM_LMS_User::login_page_url()); ?>
</h3>